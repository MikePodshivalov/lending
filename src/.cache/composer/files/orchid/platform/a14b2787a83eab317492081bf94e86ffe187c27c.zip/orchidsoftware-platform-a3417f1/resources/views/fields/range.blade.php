@component($typeForm, get_defined_vars())
    <input type="range" class="form-range" {{ $attributes }}>
@endcomponent
