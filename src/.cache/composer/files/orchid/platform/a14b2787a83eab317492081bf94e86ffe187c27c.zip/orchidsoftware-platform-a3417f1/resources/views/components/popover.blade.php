<sup class="text-black"
     role="button"
     data-controller="popover"
     data-action="click->popover#trigger"
     data-container="body"
     data-toggle="popover"
     tabindex="0"
     data-trigger="focus"
     data-placement="{{ $placement }}"
     data-delay-show="300"
     data-delay-hide="200"
     data-bs-content="{{ $content }}">
    <x-orchid-icon path="exclamation"/>
</sup>
