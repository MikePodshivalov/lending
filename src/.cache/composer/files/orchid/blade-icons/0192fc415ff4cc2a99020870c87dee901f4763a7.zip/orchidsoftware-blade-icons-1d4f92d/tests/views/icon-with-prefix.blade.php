<x-orchid-icon path="foo.house" class="icon-big" width="2em" height="2em" />
