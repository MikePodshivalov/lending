<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Active class
    |--------------------------------------------------------------------------
    |
    | Here you may set the class string to be returned when the provided routes
    | or paths were identified as applicable for the current route.
    |
    */

    'class' => 'active',

];
